<div class="card mb-3" style="max-width: 540px;">
  <div class="row g-0">
    <div class="col-md-4">
      <img src="images/1.jpeg" class="img-fluid rounded-start" alt="gambar">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title">Askiri Saipul Alam</h5>
        <p class="card-text">Hai! Gue Askir, mahasiswa STT NF Prodi Sistem Informasi.
          Gue kelahiran 2007. Selain sibuk kuliah, gue biasanya ngabisin waktu buat design dan main game untuk selingan. Salam kenal ya,</p>
        <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
      </div>
    </div>
  </div>
</div>